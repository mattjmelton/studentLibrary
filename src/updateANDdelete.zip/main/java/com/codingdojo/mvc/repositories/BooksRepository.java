package com.codingdojo.mvc.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.codingdojo.mvc.models.Books;

@Repository
public interface BooksRepository extends CrudRepository<Books, Long>{

 // this method retrieves all the books from the database
	List<Books> findAll();
 // this method find a book by their description
	List<Books> findByDescriptionContaining(String search);
 // this method counts how many titles contain a certain string
	Long countByTitleContaining(String search);
 // this method deletes a book that starts with a specific title
	Long deleteByTitleStartingWith(String search);
 // this method updates a book by id
	
 // this method deletes a book by id
	void deleteById(Long id);
}

