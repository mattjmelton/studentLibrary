package com.codingdojo.mvc.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.codingdojo.mvc.models.Books;
import com.codingdojo.mvc.services.BooksService;

@Controller
public class BooksController {
	private final BooksService booksService;
	
	public BooksController(BooksService booksService) {
		this.booksService = booksService;
	}
	//render index page and Show all books
	@RequestMapping("/books")
	public String index(Model model) {
		List<Books> books = booksService.allBooks();
		model.addAttribute("books", books);
		return "/books/index.jsp";
	}
	//route to new page to enter new book
	@RequestMapping("/books/new")
	public String newBook(@ModelAttribute("book")Books book) {
		return "/books/new.jsp";
	}
	//Post route to create new book
	@RequestMapping(value= "/books", method=RequestMethod.POST)
	public String create(@Valid @ModelAttribute("book") Books book, BindingResult result) {
		if(result.hasErrors()) {
			return "/books/new.jsp";
		}else {
			booksService.createBook(book);
			return "redirect:/books";
		}
	}
	//route to render the show ONE book
	@RequestMapping("/books/{id}")
	public String showBook(@PathVariable("id") Long id, Model model) {
		Books book = booksService.findBook(id);
		model.addAttribute("book", book);
		return "/books/show.jsp";
	}
	
	
}
