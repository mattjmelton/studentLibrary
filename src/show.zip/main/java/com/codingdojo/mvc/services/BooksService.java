package com.codingdojo.mvc.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.codingdojo.mvc.models.Books;
import com.codingdojo.mvc.repositories.BooksRepository;

@Service
public class BooksService {
	private final BooksRepository booksRepository;
	
	public BooksService(BooksRepository booksRepository) {
		this.booksRepository = booksRepository;
	}
	// returns all the books
    public List<Books> allBooks() {
        return booksRepository.findAll();
    }
    // creates a book
    public Books createBook(Books b) {
        return booksRepository.save(b);
    }
    // retrieves a book
    public Books findBook(Long id) {
        Optional<Books> optionalBook = booksRepository.findById(id);
        if(optionalBook.isPresent()) {
            return optionalBook.get();
        } else {
            return null;
        }
    }
    //update a book
    public Books updateBook(Long id, String title, String desc, String lang, Integer numOfPages) {
    	Optional<Books> optionalBook = booksRepository.findById(id);
    	if(optionalBook.isPresent()) {
    		Books updateBook = optionalBook.get();
    		
    		updateBook.setTitle(title);
    		updateBook.setDescription(desc);
    		updateBook.setLanguage(lang);
    		updateBook.setNumberOfPages(numOfPages);
    		
    		booksRepository.save(updateBook);
    		return updateBook;
    		
    	} else {
    		return null;
    	}
    }
    //delete a book
    public Books deleteBook(Long id) {
    	booksRepository.deleteById(id);
    	return null;
    }
}
