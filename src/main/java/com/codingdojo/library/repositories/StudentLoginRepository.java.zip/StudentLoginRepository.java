package com.codingdojo.library.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.codingdojo.library.models.StudentLogin;

@Repository
public interface StudentLoginRepository extends CrudRepository<StudentLogin, Integer>{
	//get login
	List<StudentLogin> findAll();
}
